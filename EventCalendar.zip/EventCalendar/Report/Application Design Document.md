# Table Definitions

### 1. User Information Table
- **Table Name: USER**
- Table Description: A table storing user information
- Column Information

| Column Name      | Data Type   | Length | Null Allowed | Default | Constraints | Description  |
| ---------------- | ----------- | ------ | ------------ | ------- | ----------- | ----------- |
| name             | VARCHAR     | 50     | N            |         |             | User name    |
| team             | VARCHAR     | 50     | Y            | None    |             | Team name    |
| is_team_manager  | BOOLEAN     |        | Y            | False   |             | Is team manager |
| request_to       | VARCHAR     | 50     | Y            | None    |             | Requested team |

### 2. Team Information Table
- **Table Name: TEAM**
- Table Description: A table storing team information
- Column Information

| Column Name      | Data Type   | Length | Null Allowed | Default | Constraints | Description   |
| ---------------- | ----------- | ------ | ------------ | ------- | ----------- | ------------- |
| id               | INT         |        | N            |         | PK          | ID            |
| team_name        | VARCHAR     | 50     | N            |         | UNIQUE      | Team name     |
| team_manager     | VARCHAR     | 50     | N            |         |             | Team manager  |
| member1          | VARCHAR     | 50     | Y            | None    |             | Member 1      |
| member2          | VARCHAR     | 50     | Y            | None    |             | Member 2      |
| member3          | VARCHAR     | 50     | Y            | None    |             | Member 3      |

### 3. Schedule Table
- **Table Name: CALENDARDATA**
- Table Description: A table storing user's schedule information
- Column Information

| Column Name      | Data Type   | Length | Null Allowed | Default | Constraints | Description      |
| ---------------- | ----------- | ------ | ------------ | ------- | ----------- | ---------------- |
| user_id          | INT         |        | N            |         | FK          | User (referencing USER table) |
| team_id          | INT         |        | N            |         | FK          | User's team (referencing TEAM table) |
| year             | INT         |        | N            |         |             | Year             |
| month            | INT         |        | N            |         |             | Month            |
| day              | INT         |        | N            |         |             | Day              |
| start_time       | TIME        |        | N            |         |             | Start time       |
| end_time         | TIME        |        | N            |         |             | End time         |
| memo             | TEXT        |        | N            |         |             | Schedule description |

---

# Program List

| NO  | Task Name          | App             | Name                  | Program Category | Program Type | Location                             |
| --- | ------------------- | --------------- | --------------------- | ---------------- | ------------ | ------------------------------------ |
| 1   | User Management     | account         | User                  | Model            | Class        | account/models.py                   |
| 2   |                     |                 | create                | View             | Function     | account/views.py                    |
| 3   |                     |                 | user_login            | View             | Function     | account/views.py                    |
| 4   |                     |                 | user_logout           | View             | Function     | account/views.py                    |
| 5   |                     |                 | user_detail           | View             | Function     | account/views.py                    |
| 6   |                     |                 | change_password       | View             | Function     | account/views.py                    |
| 7   |                     |                 | user_update           | View             | Function     | account/views.py                    |
| 8   |                     |                 | user_delete           | View             | Function     | account/views.py                    |
| 9   |                     |                 | user_team_delete      | View             | Function     | account/views.py                    |
| 10  |                     |                 | approve_request       | View             | Function     | account/views.py                    |
| 11  |                     |                 | reject_request        | View             | Function     | account/views.py                    |
| 12  |                     |                 | user_expel            | View             | Function     | account/views.py                    |
| 13  |                     |                 | CustomUserCreateForm  | Form             | Class        | account/forms.py                    |
| 14  |                     |                 | CustomPasswordChangeForm | Form           | Class        | account/forms.py                    |
| 15  |                     |                 | CustomUserChangeForm  | Form             | Class        | account/forms.py                    |
| 16  |                     |                 | create.html           | Template         | Template     | account/template/account/           |
| 17  |                     |                 | join_form.html        | Template         | Template     | account/template/account/           |
| 18  |                     |                 | login.html            | Template         | Template     | account/template/account/           |
| 19  |                     |                 | password_change.html  | Template         | Template     | account/template/account/           |
| 20  |                     |                 | update.html           | Template         | Template     | account/template/account/           |
| 21  | Team Management     | team_calendar   | Team                  | Model            | Class        | team_calendar/models.py             |
| 22  |                     |                 | team_list             | View             | Function     | team_calendar/views.py              |
| 23  |                     |                 | create_team           | View             | Function     | team_calendar/views.py              |
| 24  |                     |                 | join_team             | View             | Function     | team_calendar/views.py              |
| 25  |                     |                 | cancel_request        | View             | Function     | team_calendar/views.py              |
| 26  |                     |                 | create_team.html      | Template         | Template     | team_calendar/templates/            |
| 27  |                     |                 | list.html             | Template         | Template     | team_calendar/templates/            |
| 28  | Team Schedule Management | team_calendar | CalendarData         | Model            | Class        | team_calendar/models.py             |
| 29  |                     |                 | calendar_view         | View             | Function     | team_calendar/templates/            |
| 30  |                     |                 | delete_schedule       | View             | Function     | team_calendar/templates/            |
| 31  |                     |                 | TimeForm              | Form             | Class        | team_calendar/forms.py              |
| 32  |                     |                 | calendar.html         | Template         | Template     | team_calendar/templates/            |
| 33  | Other               |                 | home.html             | Template         | Template     | templates/                          |
| 34  |                     |                 | layout.html           | Template         | Template     | templates/                          |
