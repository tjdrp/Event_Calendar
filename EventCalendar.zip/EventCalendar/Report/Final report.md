# Final Report

## Project Topic  
### EventCalendar  
- **Purpose**: Provide a service where users can form teams and share schedules  
- **Reason for Selection**: As the final project approached, I realized the need to share schedules, especially for mentoring sessions. I thought it would be useful to have a simple way for team members to share schedules with minimal functionality, which led to the selection of this topic.

## Problems Encountered During Development and Solutions  
### 1. Model Conflict During Feature Implementation Using Views  
- Columns that shouldn't have null values were being assigned null values, or there were datatype issues due to the referencing method  
- Fixed the issue by modifying the model to align with the functionality  
- There was an issue where the column for the team name should not allow duplicates according to the feature  
- Solved by importing Django's Integrity Error to handle the issue  

### 2. Issues with HTML, CSS Tag Settings as Intended  
- The tags were not being applied or positioned correctly due to default values set for each tag  
- Resolved by applying the `!important` property to non-reflected styles  
- Fixed layout issues by adjusting the `display` and `margin` properties appropriately  

### 3. Unintended Page Responses to User Actions  
- When setting schedules, if times were entered incorrectly (e.g., start time was later than the end time), I wanted to block the modal that allows schedule setting  
- However, due to a forced page refresh, the intended behavior was not achieved  
- Solved by using `event.preventDefault()` in JavaScript during schedule setting  
- When there were too many schedules on a particular day, a warning message was shown, but the message remained even when the delete button was clicked  
- Set up the system to ensure the message wouldn't show during schedule deletion using `event.stopPropagation()` to prevent event propagation  

### 4. Unintended Redirects After Form Submission  
- For example, the calendar was set to show the current year and month by default, but after adding or deleting schedules from other months, the page redirected to the default month  
- Used hidden input fields to pass values and controlled redirection to achieve the desired behavior  

### 5. Issues with Join/Accept Requests  
- Problems occurred when users requested to join teams created by others, canceled their requests, or when the user receiving the request accepted or rejected it  
- Resolved the issue by modifying user data based on various conditions, such as pending requests, team membership, request cancellations, accept/reject actions, and team settings  

<br>

## Future Upgrade Plans  
### 1. Improve Webpage Design  
- Adjust the horizontal length of the date cells dynamically when adding schedules to the calendar  
- Upgrade by setting a maximum length or modifying the schedule display method  

### 2. Simplify Layout and Design  
- Improve design quality using methods like adding image files or integrating Bootstrap  

### 3. Review Edge Use Cases and Handle Errors via URL  
- Review potential collisions in complex situations and improve error handling  
- Examine whether unauthorized users can view or modify schedules and whether certain URLs can cause errors  

### 4. Improve Database and Models to Prevent Issues in CRUD Operations  
- There were issues referencing other tables using non-primary key data during data exchange  
- Refine Foreign Key settings, reference methods, and query methods to prevent problems  

### 5. Additional Feature Implementation  
- The purpose of schedule sharing is to coordinate schedules among team members  
- Features could include setting target schedules and time conditions for team members, blocking or warning users when setting schedules, or indicating feasible/infeasible time intervals based on the set schedule.
